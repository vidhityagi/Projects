package internshala.com.echomusik.utils


/**
 * Created by ADMIN on 6/19/2017.
 */

class CurrentSongHelper {


    var songArtist: String? = null

    var songTitle: String? = null

    var songPath: String? = null

    var currentPosition: Int = 0

    var songId: Long = 0

    var isPlaying: Boolean? = false

    var isLoop: Boolean = false

    var isShuffle: Boolean = false

    var TrackPosition: Int = 0

}